
创建数据库登录用户dbo、密码pass、以及数据库stulist。

运行initdb.py，创建相关表，并导入初始数据。

